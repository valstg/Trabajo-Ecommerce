let base = prompt("Ingrese la base del rectangulo: ")
let altura = prompt("Ingrese la altura del rectangulo: ")
base= Number(base)
altura= Number(altura)
let area = base * altura
// Mostrar en consola
console.log(" El area del rectangulo es: " + area)
//Mostrar en pantalla
document.write("<h2> El area del rectangulo es:  "+ area + "</h2>")
