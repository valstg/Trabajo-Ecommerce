let listaDeCompras = [
  "Leche",
  "Pan",
  "Huevos",
  "Fideos",
  "Manzanas",
  "Yogur",
  "Café"
];
for (let i = 0; i < listaDeCompras.length; i++) {
  console.log(listaDeCompras[i]);
  document.write("<h2>" + listaDeCompras[i] + "</h2>");
}