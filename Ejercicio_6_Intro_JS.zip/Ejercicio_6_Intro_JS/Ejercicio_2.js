let nombre = prompt("Ingrese su nombre: ")
let mensaje = "Hola " + nombre + ", ¡Bienvenido al Bootcamp!"

console.log(mensaje)
document.write(mensaje)