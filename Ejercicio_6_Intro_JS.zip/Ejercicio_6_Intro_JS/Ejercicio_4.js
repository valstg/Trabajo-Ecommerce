let color = prompt(" Ingrese un color: ");
let comida = prompt(" Ingrese una comida: ");
let lugar = prompt(" Ingrese un lugar: ");
let mensaje = `Tu color favorito es ${color}, te gusta comer ${comida} y tu lugar favorito es ${lugar}.`;
console.log(mensaje);
document.write(`<h2 class='mensaje_ej_4'> ${mensaje} </h2>`);                        