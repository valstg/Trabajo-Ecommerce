let radio = Number(prompt("Ingrese el radio del circulo: "));
let pi = 3.1416; 
let area = pi * radio * radio;
// Mostrar en consola
console.log("El area del circulo es: " + area);
// Mostrar en pantalla
document.write("<h2> El area del circulo es: " + area + "</h2>");