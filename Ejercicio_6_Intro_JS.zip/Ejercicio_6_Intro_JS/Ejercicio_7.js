let minutos = Number(prompt("Ingrese la cantidad de minutos: "));
let segundos = minutos * 60;
let horas = minutos / 60;
console.log("La cantidad de segundos es: " + segundos + " La cantidad de minutos es: " + minutos + " La cantidad de horas es: " + horas);
document.write("<h2> La cantidad de segundos es: " + segundos + ", la cantidad de minutos es: "+minutos+" y la cantidad de horas es de: "+horas+"</h2>");