let numeros = [12, -5, 7, -3, 9, -8, 15, 3, -25, 40, -33, -9];

console.log("Números positivos:");

for (let i = 0; i < numeros.length; i++) {
  if (numeros[i] > 0) {
    console.log(numeros[i]);
  }
}
